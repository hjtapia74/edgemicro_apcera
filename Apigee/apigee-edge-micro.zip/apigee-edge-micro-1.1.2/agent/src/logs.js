'use strict';
var fs = require('fs');
var path = require('path');
var debug = require('debug');
var config = require('edgeconfig').loadConfigSync();
var d = debug('agent:logs');
var forever = require('forever-monitor');
var sym = require('log-symbols');
var help = require('./http_helpers').http_helpers;
var monitors = require('./monitors').monitors;
var logs;
(function(logs_1) {
  function listFiles(res) {
    return fs.readdirSync(config.edgemicro.logging.dir)
      .filter(function(file) {
        var keep = (file.indexOf('edgemicro-') === 0) &&
          (file.indexOf('-api.log') > 0 || file.indexOf('-out.log') > 0 ||
            file.indexOf('-err.log') > 0);
        return keep;
      })
      .map(function(file) {
        return fs.realpathSync(path.join(config.edgemicro.logging.dir, file));
      });
  }

  function listActiveFiles() {
    var files = fs.readdirSync(config.edgemicro.logging.dir);
    var active = [];
    monitors.forEach(function(monitor, i, length) {
      var data = monitor.data();
      pushIfExists(data.outFile, active);
      pushIfExists(data.errFile, active);
      var pattern = new RegExp('^edgemicro-(.+)-' + data.uid +
        '-(.+)-api.log$');
      files.some(function(file) {
        if (file.match(pattern)) {
          var reqlog = path.join(config.edgemicro.logging.dir, file);
          pushIfExists(reqlog, active);
          return true;
        }
        return false;
      });
    });
    return active;
  }

  function pushIfExists(file, active) {
    if (fs.existsSync(file)) {
      active.push(fs.realpathSync(file));
    }
  }

  function list(req, res) {
    d(sym.info, 'logs.list', req.url);
    var active = listActiveFiles();
    var logs = listFiles(res)
      .map(function(file) {
        var stats = fs.statSync(file);
        var annotated = file + ' [' + stats.size + ']' + ' [' + stats.mtime
          .toISOString() + ']'; // annotate with size
        // annotate active logs
        return active.indexOf(file) === -1 ? annotated : annotated +
          ' [active]';
      });
    help.status(200, res);
    res.end(JSON.stringify(logs));
  }
  logs_1.list = list;

  function clean(req, res) {
    d(sym.info, 'logs.clean', req.url);
    var threshold;
    if (req.body.max) {
      threshold = new Date(req.body.max);
      if (isNaN(threshold)) {
        help.error(400, res, new Error('Error: invalid date format'));
      }
    }
    var active = listActiveFiles();
    var logs = listFiles(res)
      .filter(function(file) {
        return active.indexOf(file) === -1; // exclude active logs from deletion
      })
      .filter(function(file) {
        if (threshold) {
          var stats = fs.statSync(file);
          return stats.mtime.getTime() < threshold.getTime();
        } else {
          return true;
        }
      })
      .map(function(file) {
        fs.unlinkSync(file);
        return file;
      });
    help.status(200, res);
    res.end(JSON.stringify(logs));
  }
  logs_1.clean = clean;

  function get(req, res) {
    d(sym.info, 'logs.get', req.url);
    var id = req.params.id;
    if (!id) {
      help.error(400, res); // Bad Request
      return;
    }
    var logs = listFiles(res);
    var found = logs.some(function(file, i, array) {
      if (file.lastIndexOf(id) >= 0) {
        sendFile(file, res);
        return true;
      }
    });
    if (!found) {
      help.status(404, res).end(); // Not Found
    }
  }
  logs_1.get = get;

  function sendFile(fileName, res) {
    var stream = fs.createReadStream(fileName, {
      autoClose: true
    });
    stream.on('error', function(err) {
      help.error(500, res, err);
    });
    stream.on('data', function(chunk) {
      res.write(chunk);
    });
    stream.on('end', function() {
      res.end();
    });
  }
})(logs = exports.logs || (exports.logs = {}));
