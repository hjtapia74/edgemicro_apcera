'use strict';
var path = require('path');
var debug = require('debug');
var os = require('os');
var url = require('url');
var config = require('edgeconfig').loadConfigSync();
var d = debug('agent:proc');
var forever = require('forever-monitor');
var sym = require('log-symbols');
var help = require('./http_helpers').http_helpers;
var monitors = require('./monitors').monitors;
var config_loader = require('./config_loader').config_loader;
var proc;
(function(proc) {
  function get(req, res) {
    var monitor = monitors.get();
    if (!monitor) {
      help.status(404, res).end(); // Not Found
    } else {
      var info = monitor.stringify(true);
      d('get_one', info);
      help.status(200, res);
      res.end(info);
    }
  }
  proc.get = get;

  function makeErrorHandler(res) {
    return function(err) {
      d('on_error', err);
      help.error(500, res, err);
    };
  };

  function makeStartHandler(res, uid, child, edgeConf) {
    monitors.push(res, uid, child, edgeConf);
    return function(data) {
      var monitor = monitors.get();
      if (!monitor) {
        help.status(404, res).end(); // Not Found
      } else {
        var info = monitor.stringify(true);
        help.status(200, res).end(info); // OK
      }
    };
  };

  function makeCycleHandler(res, operation, edgeConf) {
    return function(data) {
      d('on_' + operation, data.uid);
      console.info(data.uid, 'on', operation);
      if (operation === 'exit') {
        if (data.running)
          process.kill(data.pid); // kill if still running
        // remove the exited process from list of active monitors
        monitors.pop(data.uid);
      }
      var info = monitors.stringify(data, true);
      help.status(200, res).end(info); // OK
    };
  };
  // make a uid for log files from the current timestamp encoded as base64
  // this should be sufficiently unique for our purpose
  //   as long as the monitored process is not restarted within a millisecond
  function makeUid() {
    var timestamp = new Buffer(String(Date.now())).toString('base64');
    var filler = timestamp.indexOf('='); // remove trailing equals (cosmetic)
    var uid = timestamp.substr(0, filler > 0 ? filler : timestamp.length);
    return uid;
  }

  function extractKeys(req) {
    var keys = {};
    Object.keys(req.body).some(function(key) {
      if (key === 'args') {
        var args = req.body[key];
        // extract (and remove) key and secret from args if present
        for (var arg = args.shift(); arg; arg = args.shift()) {
          if (arg === '--key')
            keys['key'] = args.shift();
          else if (arg === '--secret')
            keys['secret'] = args.shift();
          else
            args.push(arg);
        }
        return true;
      }
    });
    return keys;
  }
  proc.extractKeys = extractKeys;

  function startCommon(edgeConf, res, args) {
    var uid = makeUid();
    var options = {
      uid: uid,
      sourceDir: config.edgemicro.home,
      cwd: config.edgemicro.home,
      max: config.agent.max_times,
      minUptime: config.agent.min_uptime,
      spinSleepTime: config.agent.spin_sleep_time,
      outFile: path.join(config.edgemicro.logging.dir, 'edgemicro-' + os.hostname() +
        '-' + uid + '-out.log'),
      errFile: path.join(config.edgemicro.logging.dir, 'edgemicro-' + os.hostname() +
        '-' + uid + '-err.log'),
      watch: false
    };
    if (!checkForLoopback(edgeConf)) {
      console.error('Error - loopback scenario identified, halting start-up');
      help.error(508, res);
      return false;
    }
    if (args)
      Object.keys(args).forEach(function(key) {
        options[key] = args[key]; // merge args properties into options
      });
      
    // add uid as an env var to tell the edge micro instance its uid
    options['env'] = options['env'] || {};
    
    var child;
    if(config.edgemicro.debug){
        var debugMicro = config.edgemicro.debug;
        var dir = options['sourceDir'];        
        var port = debugMicro.port || process.debugPort+1; 
        var args = debugMicro.args;
        var debugString = '--debug-brk='+port;
        debugString = args ? debugString + " " + args : debugString;
        !port && console.error('could not find a port config'); 
        console.log('starting in debug mode on port ' + port + " with args " + debugString);
        delete options['sourceDir']; // remove sourceDir or else it gets appended        
        child = new forever.Monitor(['node',debugString,(dir + path.sep || "")+ 'index.js'], options);
    }else{
        child = new forever.Monitor('index.js', options);      
    }
    
    options['env']['EDGEMICRO_UID'] = uid;
    d('starting edge micro with options', options);
    child.once('error', makeErrorHandler(res));
    child.once('start', makeStartHandler(res, uid, child, edgeConf));
    child.once('stop', makeCycleHandler(res, 'stop', edgeConf));
    child.once('restart', makeCycleHandler(res, 'restart', edgeConf));
    child.once('exit', makeCycleHandler(res, 'exit', edgeConf));
    child.start();
    return true;
  }

  function startImmediate(edgeConf, args) {
    return startCommon(edgeConf, {
      setHeader: function() {},
      write: function(message) {
        d(sym.info, message);
      },
      end: function(message) {
        d(message ? sym.info + ' ' + message : '');
      }
    }, args);
  }
  proc.startImmediate = startImmediate;

  function start(req, res, edgeConf) {
    d(sym.info, 'proc.start', req.url, JSON.stringify(req.body));
    var options = {};
    Object.keys(req.body).forEach(function(key) {
      if (key !== 'script') {
        options[key] = req.body[key];
      }
    });
    return startCommon(edgeConf, res, options);
  }
  proc.start = start;

  function resetEventHandler(monitor, operation, res, edgeConf) {
    var foreverMonitor = monitor.forever();
    // remove existing handlers, if any
    foreverMonitor.removeAllListeners('error');
    foreverMonitor.removeAllListeners('start');
    foreverMonitor.removeAllListeners('stop');
    foreverMonitor.removeAllListeners('restart');
    foreverMonitor.removeAllListeners('exit');
    // reset event handlers to capture the updated res object
    foreverMonitor.once('error', makeCycleHandler(res, 'error', edgeConf));
    foreverMonitor.once('restart', makeCycleHandler(res, 'restart', edgeConf));
    if (operation === 'reload') {
      var keys = {
        key: edgeConf.analytics.key,
        secret: edgeConf.analytics.secret
      };
      config_loader.init(keys, function(conf) {
        if (conf._hash !== edgeConf._hash) {
          edgeConf = conf; // save updated conf, and initiate a graceful restart
          monitor.write(JSON.stringify({
            command: 'restart'
          }), function(data) {
            help.status(200, res);
            res.end(data); // "ack"
          });
        } else {
          help.status(200, res);
          res.end('"nack"'); // JSON.stringify('nack')
        }
      });
    } else if (operation === 'restart') {
      monitor.write(JSON.stringify({
        command: operation
      }), function(data) {
        help.status(200, res);
        res.end(data);
      });
    } else {
      if (operation === 'stop') {
        foreverMonitor.once('exit', makeCycleHandler(res, 'exit', edgeConf));
        foreverMonitor.kill(true); // don't respawn please
      } else if (operation === 'reset') {
        foreverMonitor.kill(false); // respawn please
      }
    }
  }

  function cycle(req, res, edgeConf) {
    d(sym.info, 'proc.cycle', req.url, req.body.operation);
    var operation = req.body.operation;
    if (operation !== 'stop' &&
      operation !== 'restart' &&
      operation !== 'reload' &&
      operation !== 'reset') {
      help.error(400, res); // Bad Request
      return;
    }
    // responses will be sent by event handlers set on monitor when created
    var monitor = monitors.get();
    if (!monitor) {
      help.status(404, res).end(); // Not Found
    } else {
      resetEventHandler(monitor, operation, res, edgeConf);
    }
  }
  proc.cycle = cycle;
})(proc = exports.proc || (exports.proc = {}));
// identifies loopback scenarios between edgemicro and edgemicro-aware proxies
function checkForLoopback(conf) {
  var ni = os.networkInterfaces(); // all possible network interfaces
  var keys = Object.keys(ni);
  var conflict;
  // iterate over all downloaded proxies
  return !conf.proxies.some(function(proxy) {
    var parsedProxy = url.parse(proxy['url']);
    // iterate over network interfaces
    return Object.keys(ni).some(function(interfaces) {
      return ni[interfaces].some(function(inter) {
        return (inter['address'] === parsedProxy.hostname &&
          conf.edgemicro.port == parsedProxy.port);
      });
    });
  });
}
