'use strict';
var fs = require('fs');
var net = require('net');
var os = require('os');
var path = require('path');
var debug = require('debug');
var d = debug('agent:monitors');
var sym = require('log-symbols');
var help = require('./http_helpers').http_helpers;
var monitors;
(function (monitors) {
    var Monitor = (function () {
        function Monitor(res, uid, foreverMonitor, edgeConf) {
            this.uid = uid;
            this.sock = path.join(process.platform === 'win32' ? '\\\\?\\pipe\\' : os.tmpdir(), 'edgemicro-' + uid + '.sock');
            this.foreverMonitor = foreverMonitor;
            var that = this;
            this.server = net.createServer(function (connection) {
                if (that.client) {
                    d(sym.warn, 'disconnecting edge micro');
                    that.client.destroy(); // disconnect previous
                }
                d(sym.info, 'edge micro connected');
                that.client = connection;
                connection.on('data', function (data) {
                    var message = JSON.parse(data.toString());
                    d(sym.info, 'got message from edge micro');
                    if (that.ondata)
                        that.ondata(data);
                    else
                        d(sym.warn, 'no handler, dropping message from edge micro');
                });
                connection.on('error', function (err) {
                    d(sym.info, 'error talking to edge micro', err);
                });
                connection.on('close', function () {
                    d(sym.info, 'edge micro disconnected');
                    that.client = null;
                });
                that.sendEdgeConf(res, edgeConf);
            });
            this.server.listen(this.sock);
            this.server.on('error', function (err) {
                console.error(sym.error, 'server error talking to edge micro', err);
            });
            d(sym.info, 'agent listening for edge micro connections');
        }
        Monitor.prototype.connected = function () {
            return !!this.client;
        };
        Monitor.prototype.close = function () {
            if (this.client)
                this.client.destroy();
            if (this.server) {
                this.server.close();
                this.server = null;
            }
        };
        Monitor.prototype.destroy = function () {
            if (fs.existsSync(this.sock)) {
                fs.unlink(this.sock);
            }
        };
        Monitor.prototype.forever = function () {
            return this.foreverMonitor;
        };
        Monitor.prototype.write = function (data, ondata) {
            if (!this.client) {
                throw new Error('not connected');
            }
            if (!ondata) {
                throw new Error('ondata handler must not be null');
            }
            d('sending message to edge micro');
            this.ondata = ondata;
            var frameLength = new Buffer(8);
            frameLength.writeDoubleLE(data.length, 0);
            this.client.write(frameLength); // 8-byte frame length header
            this.client.write(data);
        };
        Monitor.prototype.data = function () {
            return this.foreverMonitor.data;
        };
        Monitor.prototype.stringify = function (isChild) {
            return monitors.stringify(this.foreverMonitor.data, isChild);
        };
        Monitor.prototype.sendEdgeConf = function (res, edgeConf) {
            var payload = {
                'command': 'start',
                'data': edgeConf
            };
            this.write(JSON.stringify(payload), function (data) {
                var replyJSON = data.toString();
                var reply = JSON.parse(replyJSON);
                if (reply === 'ack') {
                    var info = this.stringify(true);
                    help.status(200, res).end(info); // OK
                }
                else {
                    help.status(500, res).end(replyJSON);
                    // startup failed, kill this monitor
                    var monitor = pop();
                    monitor.foreverMonitor.kill(true);
                }
            });
        };
        return Monitor;
    })();
    monitors.Monitor = Monitor;
    var active = null;
    function stringify(data, isChild) {
        var source = isChild ? data : data.childData;
        var subset = {};
        ['pid', 'uid', 'running', 'restarts'].forEach(function (key) {
            subset[key] = source[key];
        });
        if (data['ctime']) {
            subset['since'] = new Date(+data['ctime']);
        }
        return JSON.stringify(subset);
    }
    monitors.stringify = stringify;
    function forEach(iterator) {
        if (active)
            iterator(active, 0, 1);
    }
    monitors.forEach = forEach;
    function push(res, uid, foreverMonitor, edgeConf) {
        active = new Monitor(res, uid, foreverMonitor, edgeConf);
        d('pushed', active.uid);
    }
    monitors.push = push;
    function pop() {
        var monitor = active;
        if (monitor) {
            active = null;
            monitor.close();
            monitor.destroy();
        }
        d('popped', monitor ? monitor.uid : null);
        return monitor;
    }
    monitors.pop = pop;
    function get() {
        d('get', active ? active.uid : null);
        return active;
    }
    monitors.get = get;
})(monitors = exports.monitors || (exports.monitors = {}));
