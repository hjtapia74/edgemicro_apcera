'use strict';
var debug = require('debug');
var d = debug('agent:mon');
var sym = require('log-symbols');
var help = require('./http_helpers').http_helpers;
var monitors = require('./monitors').monitors;
var mon;
(function (mon) {
    function get(req, res) {
        d(sym.info, 'mon.get', req.url, req.body);
        var monitor = monitors.get();
        if (!monitor) {
            help.status(404, res).end(); // Not Found
        }
        else {
            monitor.write(JSON.stringify({ 'command': req.body.m }), function (data) {
                help.status(200, res);
                res.end(data);
            });
        }
    }
    mon.get = get;
    function plugin(req, res) {
        d(sym.info, 'mon.plugin', req.url, req.body);
        var monitor = monitors.get();
        if (!monitor) {
            help.status(404, res).end(); // Not Found
        }
        else {
            monitor.write(JSON.stringify({ 'command': req.body.m }), function (data) {
                help.status(200, res);
                res.end(data);
            });
        }
    }
    mon.plugin = plugin;
})(mon = exports.mon || (exports.mon = {}));
