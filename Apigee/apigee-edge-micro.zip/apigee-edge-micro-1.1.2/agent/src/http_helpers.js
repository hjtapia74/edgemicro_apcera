/// <reference path="../../typings/node/node"/>
'use strict';
var http = require('http');
var debug = require('debug');
var sym = require('log-symbols');
var d = debug('agent');
var http_helpers;
(function (http_helpers) {
    function status(code, res) {
        var outgoingMessage = res; // cast to node.http.OutgoingMessage to gain access to 'finished'
        if (!outgoingMessage.finished) {
            res.setHeader('content-type', 'application/json');
        }
        res.statusCode = code;
        d(sym.info, code);
        return res;
    }
    http_helpers.status = status;
    function error(code, res, err) {
        var message = JSON.stringify(err ? err.message : http.STATUS_CODES[code]);
        var outgoingMessage = res; // cast to node.http.OutgoingMessage to gain access to 'finished'
        if (!outgoingMessage.finished) {
            res.setHeader('content-type', 'application/json');
            res.statusCode = code;
            res.write(message);
        }
        if (code >= 400) {
            res.end();
        }
        d(sym.error, code, message);
    }
    http_helpers.error = error;
})(http_helpers = exports.http_helpers || (exports.http_helpers = {}));
