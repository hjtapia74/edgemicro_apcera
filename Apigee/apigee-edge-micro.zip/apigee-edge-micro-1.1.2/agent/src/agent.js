'use strict';
var express = require('express');
var config = require('edgeconfig').loadConfigSync();
var bodyParser = require('body-parser');
var config_loader = require('./config_loader').config_loader;
var help = require('./http_helpers').http_helpers;
var sym = require('log-symbols');
var proc = require('./proc').proc;
var logs = require('./logs').logs;
var mon = require('./mon').mon;
var port = config.agent.port || process.env.PORT || 9000;
var hostname = config.agent.address || process.env.ADDRESS;
var edgeConf;
var server;
var app;
// use to initialize a new instance of the agent
function init(cb) {
  port = config.agent.port || process.env.PORT || 9000;
  hostname = config.agent.address || process.env.ADDRESS;
  // initialize new express app and begin set up
  app = express();
  app.use(bodyParser.json());
  app.route('/proc')
    .get(proc.get)
    .post(function(req, res) {
      var keys = proc.extractKeys(req);
      if (edgeConf) {
        proc.start(req, res, edgeConf);
      } else {
        config_loader.init(keys, function(conf) {
          var started = proc.start(req, res, conf);
          if (started) {
            edgeConf = conf;
          }
        });
      }
    })
    .put(function(req, res) {
      if (edgeConf) {
        proc.cycle(req, res, edgeConf);
      } else {
        help.error(400, res); // Bad Request
      }
    });
  app.route('/logs')
    .get(logs.list)
    .delete(logs.clean);
  app.route('/logs/:id')
    .get(logs.get);
  app.route('/mon')
    .get(mon.get);
  app.all('/plugin', mon.plugin);
  if (hostname) {
    server = app.listen(port, hostname, function() {
      console.info(sym.info, 'edge micro agent listening on', hostname +
        ':' + port);
    });
  } else {
    server = app.listen(port, function() {
      console.info(sym.info, 'edge micro agent listening on', port);
    });
  }
  // autostart if key and secret are available as env vars
  var keys = {
    key: process.env['EDGEMICRO_KEY'],
    secret: process.env['EDGEMICRO_SECRET']
  };
  if (keys.key && keys.secret) {
    start(keys, function(err, conf) {
      if (err) {
        console.error('edgemicro - failed to start edge micro: ', err);
        return cb(new Error(err));
      }
      return cb();
    });
  } else {
    if (!server) {
      return cb(new Error('edgemicro - failure starting agent server'));
    }
    return cb();
  }
}
// use to close down the current agent connections
function close(cb) {
  if (!server) {
    console.log('edgemicro - nothing running to close');
    return cb();
  }
  server.close(cb);
}
// use to start edgemicro instance with key and secret
function start(args, cb) {
  if (!server) {
    return cb(new Error('edgemicro - no agent running, cannot start'));
  }
  if (args.key && args.secret) {
    config_loader.init(args, function(conf) {
      var started = proc.startImmediate(conf, args);
      if (started) {
        edgeConf = conf; // save config to global variable
      }
      cb(null, conf);
    });
  } else {
    cb(new Error('edgemicro - start needs EDGEMICRO_KEY and EDGEMICRO_SECRET'));
  }
}
module.exports = {
  init: init,
  close: close,
  start: start
};
// accessor for agent config
Object.defineProperty(module.exports, 'config', {
  get: function() {
    return edgeConf;
  }
});
