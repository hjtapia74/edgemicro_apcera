'use strict';
var assert = require('assert');
var crypto = require('crypto');
var fs = require('fs');
var path = require('path');
var util = require('util');
var url = require('url');
var async = require('async');
var debug_ = require('debug');
var request = require('request');
var yaml = require('js-yaml');
var _ = require('lodash');
var config = require('edgeconfig').loadConfigSync();
var agent_config_validator = require('./agent_config_validator');
var config_validator = require('./config_validator');
var debug = debug_('agent:config');
var config_loader;
(function(config_loader) {
  var save_path;

  function loadStatus(message, url, err, response, body, cb) {
    var failed = err || (response && response.statusCode !== 200);
    console.info(failed ? 'warning:' : 'info:', message, 'download from', url,
      'returned', response ? (response.statusCode + ' ' + response.statusMessage) :
      '', err ? err : '');
    if (err) {
      cb(err, body);
    } else if (response && response.statusCode !== 200) {
      cb(new Error(response.statusMessage), body);
    } else {
      cb(err, body);
    }
  }

  function load(keys, callback) {
    var options = {};
    if (config.edge_config.proxy) {
      options['proxy'] = config.edge_config.proxy;
    }
    if (typeof config.edge_config.proxy_tunnel !== 'undefined') {
      options['tunnel'] = config.edge_config.proxy_tunnel;
    }
    async.parallel([
      function(cb) {
        var opts = _.clone(options);
        opts['url'] = config.edge_config.bootstrap;
        opts['auth'] = {
          user: keys.key,
          pass: keys.secret,
          sendImmediately: true
        };
        request.get(opts, function(err, response, body) {
          loadStatus('config', config.edge_config.bootstrap, err,
            response, body, cb);
        });
      },
      function(cb) {
        var opts = _.clone(options);
        opts['url'] = config.edge_config.products;
        request.get(opts, function(err, response, body) {
          loadStatus('products', config.edge_config.products, err,
            response, body, cb);
        });
      },
      function(cb) {
        var opts = _.clone(options);
        opts['url'] = config.edge_config.jwt_public_key;
        request.get(opts, function(err, response, body) {
          loadStatus('jwt_public_key', config.edge_config.jwt_public_key,
            err, response, body, cb);
        });
      }
    ], function(err, results) {
      debug('error %s, proxies %s, products %s, jwt_public_key %s', err,
        results[0], results[1], results[2]);
      if (err) {
        console.error('warning:',
          'error downloading config, please check bootstrap configuration',
          err);
      }
      var proxyInfo;
      try {
        proxyInfo = results[0] ? JSON.parse(results[0]) : {
          apiProxies: []
        };
      } catch (err) {
        console.error('warning:', 'error parsing downloaded proxy list',
          err);
      }
      var proxies = proxyInfo && proxyInfo.apiProxies ? proxyInfo.apiProxies : [];
      if (!proxies) {
        console.error('warning:',
          'no edge micro proxies found in response');
        proxies = [];
      }
      if (proxies.length === 0) {
        console.error('warning:', 'no edge micro proxies found in org');
      } else {
        console.info('downloaded proxies', util.inspect(proxies, {
          colors: true
        }));
      }
      var productInfo;
      try {
        productInfo = results[1] ? JSON.parse(results[1]) : {
          apiProduct: []
        };
      } catch (err) {
        console.error('warning:', 'error parsing downloaded product list',
          err);
      }
      if (!productInfo) {
        console.error('warning:',
          'no edge micro products found in response');
      }
      var products = productInfo && productInfo.apiProduct ? productInfo.apiProduct : [];
      if (!products) {
        console.error('warning:', 'no products found in response');
        products = [];
      }
      if (products.length === 0) {
        console.error('warning:', 'no products found in org');
      } else {
        console.info('downloaded products', util.inspect(products, {
          colors: true
        }));
      }
      if (!config.oauth)
        config.oauth = {};
      if (results.length > 1 && results[2]) {
        config.oauth.public_key = results[2]; // save key in oauth section
        console.info('downloaded jwt_public_key', util.inspect(config.oauth
          .public_key, {
            colors: true
          }));
      } else {
        console.error('warning:', 'failed to download jwt_public_key');
      }
      var hash = 0;
      if (results[0] && results[1] && results[2]) {
        // compute a checksum comprising the proxies, products and the public key
        // to be able to detect if either changes
        var md5 = crypto.createHash('md5');
        md5.update(results[0], 'utf8');
        md5.update(results[1], 'utf8');
        md5.update(results[2], 'utf8');
        hash = md5.digest('hex');
      }
      callback(null, proxies, products, hash);
    });
  };

  function init(keys, callback) {
    agent_config_validator.validate(config);
    var bootstrapUrl = url.parse(config.edge_config.bootstrap);
    var publicKeyUrl = url.parse(config.edge_config.jwt_public_key);
    if (bootstrapUrl.hostname === 'apigee.net' || bootstrapUrl.pathname.indexOf(
        '...') > 0 ||
      publicKeyUrl.hostname === 'apigee.net' || publicKeyUrl.pathname.indexOf(
        '...') > 0) {
      console.error(
        'it looks like edge micro has not been configured, please see the admin guide'
      );
      process.exit(1);
    }
    // derive products and oauth uris from jwt_public_key config
    config.edge_config.products = config.edge_config.jwt_public_key.replace(
      'publicKey', 'products');
    config.oauth.verify_api_key_url = config.edge_config.jwt_public_key.replace(
      'publicKey', 'verifyApiKey');
    // derive analytics uri from bootstrap config
    if (!config.analytics)
      config.analytics = {};
    config.analytics.uri = config.edge_config.bootstrap.replace('bootstrap',
      'axpublisher');
    config.analytics.source = 'microgateway'; // marker
    config.analytics.proxy = 'dummy'; // placeholder
    config.analytics.proxy_revision = 1; // placeholder
    config.analytics.compress = false; // turn off analytics payload compression
    // the default value of 5s allows a max of 100 records/s with a batch size of 500
    // an interval of 250 ms allows 4 batches of 500, for a max throughput of 2k/s
    config.analytics.flushInterval = 250;
    // propagate proxy configuration to the edgemicro section for use by edgemicro
    if (config.edge_config.proxy) {
      config.edgemicro.proxy = config.edge_config.proxy;
      config.edgemicro.proxy_tunnel = config.edge_config.proxy_tunnel;
    }
    // extract org and env from the bootstrap config uri
    var org = /organization\/(.+)\/environment/.exec(config.edge_config.bootstrap)[
      1];
    var env = /environment\/(.+)$/.exec(config.edge_config.bootstrap)[1];
    assert(org, 'unable to determine org from edge config bootstrap uri');
    assert(env, 'unable to determine env from edge config bootstrap uri');
    var save_file = util.format('edgemicro-config-%s-%s.yaml', org, env);
    save_path = path.join(config.edgemicro.logging.dir, save_file);
    // initiate an immediate load, and setup retries if that fails
    load(keys, function(err, proxies, products, hash) {
      if (proxies &&
        products &&
        hash != 0) {
        mergeAndReturnConfig(null, proxies, products, hash, keys,
          callback);
      } else {
        // check if we have a retry_interval specified
        // any value less than 5 seconds is assumed invalid and ignored
        if (config.edge_config.retry_interval && config.edge_config.retry_interval >
          5000) {
          var retry = setInterval(function() {
            load(keys, function(err, proxies, products, hash) {
              if (proxies &&
                products) {
                mergeAndReturnConfig(retry, proxies, products,
                  hash, keys, callback);
              }
            });
          }, config.edge_config.retry_interval);
        }
        // start with the cached copy while we retry updates in the background
        var mergedConfig = loadConfigSync();
        if (mergedConfig) {
          console.info('loaded cached config from', save_path);
          mergeKeys(mergedConfig, keys); // merge keys before sending to edge micro
          callback(mergedConfig);
        } else {
          console.error('fatal:',
            'cached config not available, unable to continue');
          process.exit(1);
        }
      }
    });
  }
  config_loader.init = init;;

  function mergeKeys(mergedConfig, keys) {
    assert(keys.key, 'key is missing');
    assert(keys.secret, 'secret is missing');
    // copy keys to analytics section
    if (!mergedConfig.analytics)
      mergedConfig.analytics = {};
    mergedConfig.analytics.key = keys.key;
    mergedConfig.analytics.secret = keys.secret;
    // copy keys to quota section
    if (mergedConfig.quota) {
      Object.keys(mergedConfig.quota).forEach(function(name) {
        var quota = mergedConfig.quota[name];
        quota.key = keys.key;
        quota.secret = keys.secret;
      });
    }
  }

  function merge(proxies, products, hash) {
    var updates = _.clone(config);
    // copy properties to edge micro section
    if (!updates.edgemicro)
      updates.edgemicro = {};
    updates.edgemicro.port = config.edgemicro.port;
    // copy properties to oauth section
    if (!updates.oauth)
      updates.oauth = {};
    updates.oauth.path_to_proxy = products.path_to_proxy;
    updates.oauth.product_to_proxy = products.product_to_proxy;
    var mergedConfig = {};
    Object.keys(updates).forEach(function(key) {
      if (key !== 'agent' && key !== 'edge_config') {
        mergedConfig[key] = updates[key];
      }
    });
    mergedConfig['proxies'] = proxies;
    mergedConfig['path_to_proxy'] = products.path_to_proxy;
    mergedConfig['product_to_proxy'] = products.product_to_proxy;
    mergedConfig['quota'] = products.product_to_quota;
    mergedConfig['_hash'] = hash;
    if (mergedConfig['quota']) {
      var uri = updates.edge_config.bootstrap.replace('bootstrap', 'quotas');
      Object.keys(mergedConfig['quota']).forEach(function(name) {
        mergedConfig['quota'][name].uri = uri;
      });
    }
    return mergedConfig;
  }
  var refreshTimer;

  function mergeAndReturnConfig(retry, proxies, products, hash, keys,
    callback) {
    var mergedConfig = merge(mapEdgeProxies(proxies), mapEdgeProducts(
      products), hash);
    if (retry !== null)
      clearInterval(retry); // we have a valid bootstrap config
    // setup periodic refresh if configured
    // any value less than 1 hour is assumed invalid and ignored
    if (config.edge_config.refresh_interval && config.edge_config.refresh_interval >
      3600000) {
      refreshTimer = setInterval(function() {
        load(keys, function(err, proxies, products, hash) {
          if (err) {
            return;
          }
          if (proxies &&
            products &&
            hash !== mergedConfig._hash) {
            try {
              var refreshedConfig = merge(mapEdgeProxies(proxies),
                mapEdgeProducts(products), hash);
              saveAndReturnConfig('refreshed config', refreshedConfig,
                keys, callback);
            } catch (invalid) {
              console.error('invalid merged config', invalid);
            }
          } else {
            debug('ignoring unchanged config');
          }
        });
      }, config.edge_config.refresh_interval);
    }
    saveAndReturnConfig('bootstrap config', mergedConfig, keys, callback);
  }

  function saveAndReturnConfig(message, mergedConfig, keys, callback) {
    config_validator.validate(mergedConfig);
    if (mergedConfig._hash != 0) {
      saveConfig(mergedConfig);
    }
    mergeKeys(mergedConfig, keys); // merge keys before sending to edge micro
    callback(mergedConfig);
  }

  function mapEdgeProxies(proxies) {
    var mappedProxies = [];
    assert(Array.isArray(proxies), 'proxies should be an array');
    proxies.forEach(function(target) {
      var tgt = {};
      tgt['max_connections'] = target['maxConnections'] || -1;
      Object.keys(target).forEach(function(key) {
        switch (key) {
          case 'apiProxyName':
            tgt['name'] = target[key];
            break;
          case 'proxyEndpoint':
            var proxyEndpoint = target[key];
            if (proxyEndpoint) {
              tgt['proxy_name'] = proxyEndpoint['name'];
              tgt['base_path'] = proxyEndpoint['basePath'];
            }
            break;
          case 'targetEndpoint':
            var targetEndpoint = target[key];
            if (targetEndpoint) {
              tgt['target_name'] = targetEndpoint['name'];
              tgt['url'] = targetEndpoint['url'];
            }
            break;
          default:
            // copy over unknown properties
            tgt[key] = target[key];
        }
      });
      if (validateTarget(tgt)) {
        mappedProxies.push(tgt);
      }
    });
    return mappedProxies;
  }
  // note: path_to_proxy as written below is broken, one product path can have multiple proxies
  function mapEdgeProducts(products) {
    //const path_to_proxy = {};
    var product_to_quota = {};
    var product_to_proxy = {};
    assert(Array.isArray(products), 'products should be an array');
    products.forEach(function(product) {
      assert(Array.isArray(product.proxies), 'proxies for product ' +
        product + ' should be an array');
      product.proxies.forEach(function(proxy) {
        if (product_to_proxy[product.name]) {
          product_to_proxy[product.name].push(proxy);
        } else {
          product_to_proxy[product.name] = [proxy];
        }
        if (product.quota) {
          product_to_quota[product.name] = {
            allow: product.quota,
            interval: product.quotaInterval,
            timeUnit: product.quotaTimeUnit,
            bufferSize: 10000
          };
        }
        //if (product.apiResources) {
        //  assert(Array.isArray(product.apiResources), 'apiResources for product ' + product + ' should be an array');
        //  product.apiResources.forEach(function(resource) {
        //    path_to_proxy[resource] = proxy;
        //  });
        //}
      });
    });
    return {
      //path_to_proxy: path_to_proxy,
      product_to_proxy: product_to_proxy,
      product_to_quota: product_to_quota
    };
  }

  function validateTarget(target) {
    if (target.base_path && target.base_path.length > 0 &&
      target.url && target.url.length > 0) {
      return true;
    } else {
      debug('dropping invalid target %o', target);
      return false;
    }
  }

  function saveConfig(mergedConfig) {
    assert(save_path, 'save_path is not set');
    var save = {}; // a copy of the config minus event emitter properties
    Object.keys(mergedConfig).forEach(function(key) {
      if (key.indexOf('_') === 0)
        return; // skip private properties
      save[key] = mergedConfig[key];
    });
    var dump = yaml.safeDump(save, {
      skipInvalid: true
    });
    fs.writeFile(save_path, dump, function(err) {
      if (err) {
        console.error('error saving config to', save_path, err);
      }
    });
  }
  // returns true if load from disk was successful
  function loadConfigSync() {
    assert(save_path, 'save_path is not set');
    if (!fs.existsSync(save_path)) {
      console.error('saved config does not exist', save_path);
      return false;
    }
    var stat = fs.statSync(save_path);
    if (!stat.isFile()) {
      console.error('saved config is not a file', save_path);
      return false;
    }
    if (stat.size === 0) {
      console.error('saved config is empty', save_path);
      return false;
    }
    var content;
    try {
      content = yaml.safeLoad(fs.readFileSync(save_path).toString());
      content._hash = 0; // indicates this is a cached config
    } catch (err) {
      console.error('error reading config from', save_path, err);
    }
    return content;
  }
})(config_loader = exports.config_loader || (exports.config_loader = {}));
