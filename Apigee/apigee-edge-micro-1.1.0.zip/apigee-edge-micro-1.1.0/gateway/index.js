/// <reference path="../typings/node/node.d.ts" />

'use strict';

var fs = require('fs');
var debug = require('debug')('gateway:index');
var yaml = require('js-yaml');
var yargs = require('yargs');
var util = require('util');

var argv = require('yargs')
  .help('?')
  .alias('?', 'help')
  .usage('Usage $0 [-k key] [-s secret] [-u] [-c config_file_path]')
  .alias('k', 'key')
  .nargs('k', 1)
  .alias('s', 'secret')
  .nargs('s', 1)
  .alias('u', 'unsupervised')
  .alias('c', 'config')
  .nargs('c', 1)
  .strict()
  .argv;

// make a uid for log files from the current timestamp encoded as base64
// this should be sufficiently unique for our purpose
//   as long as the monitored process is not restarted within a millisecond
function makeUid() {
  var timestamp = new Buffer(String(Date.now())).toString('base64');
  var filler = timestamp.indexOf('='); // remove trailing equals (cosmetic)
  return timestamp.substr(0, filler > 0 ? filler : timestamp.length);
}

function loadConfig() {
  if (!argv.config) {
    console.error('edgemicro config path not specified');
    process.exit(1);
  }
  var path = argv.config;
  if (!fs.existsSync(path)) {
    console.error('edgemicro config does not exist', path);
    process.exit(1);
  }
  var stat = fs.statSync(path);
  if (!stat.isFile()) {
    console.error('edgemicro config is not a file', path);
    process.exit(1);
  }
  if (stat.size === 0) {
    console.error('edgemicro config file is empty', path);
    process.exit(1);
  }

  var content;
  try {
    content = yaml.safeLoad(fs.readFileSync(path).toString());
  } catch(err) {
    console.error('error reading edgemicro config from', path, err);
    process.exit(1);
  }
  return content;
}

if (argv.unsupervised) {
  if (!argv.key) {
    console.error('key is required in unsupervised mode');
    process.exit(1);
  }

  if (!argv.secret) {
    console.error('secret is required in unsupervised mode');
    process.exit(1);
  }

  var config = loadConfig();

  // merge keys into config
  if (!config.analytics) config.analytics = {};
  config.analytics.key = argv.key;
  config.analytics.secret = argv.secret;

  // copy keys to quota section
  if (config.quota) {
    Object.keys(config.quota).forEach(function(name) {
      var quota = config.quota[name];
      quota.key = argv.key;
      quota.secret = argv.secret;
    });
  }

  config.uid = makeUid();
  debug('starting edgemicro unsupervised');
  debug('loaded config ' + util.inspect(config, {colors: true}));
  require('./lib/gateway').start(config, function(err) {
    if (err) {
      console.error('error starting edge micro', err);
      process.exit(1);
    }
  });
} else {
  require('./lib/monitor')();
}
